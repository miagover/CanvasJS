windowWidth = window.innerWidth;
windowHeight = window.innerHeight;

var canvas = document.getElementById("mainCanvas");
canvas.width = windowWidth;
canvas.height = windowHeight;

var ctx = canvas.getContext("2d");
ctx.font = "bold 30px Georgia";
ctx.fillText("Wordle", canvas.width/2-60, 50);

let row1 = new Row(50);
row1.draw();