class Square {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.color = 	"white";
    this.dimensions = 50;
  }

  draw() {
    console.log("square")
    ctx.fillStyle = "black";
    ctx.fillRect(this.x-1, this.y-1, this.dimensions+2, this.dimensions+2)
    ctx.fillStyle = "white";
    ctx.fillRect(this.x, this.y, this.dimensions, this.dimensions);
    
  }

  setColor(color) {
    this.color = color;
  }

}

class Row {
  contructor(y) {
    this.y = y;
    this.sq1 = new Square(canvas.width/2-133, this.y);
    this.sq2 = new Square(canvas.width/2-79, this.y);
    this.sq3 = new Square(canvas.width/2-25, this.y);
    this.sq4 = new Square(canvas.width/2+29, this.y);
    this.sq5 = new Square(canvas.width/2+83, this.y);
  }

  draw() {
    console.log("draw");
    this.sq1.draw();
    console.log("draw");
    this.sq2.draw();
    this.sq3.draw();
    this.sq4.draw();
    this.sq5.draw();
  }
}
